Instruction to follow:
1.Database Folder Contents: The DB folder contains three key files: a script file, a .bak backup file, and the actual database with its log file. In case of any issues, you can resolve them by either restoring from the .bak file, running the script, or attaching the database file using SQL Management Studio.
2.SQL Management Studio Version: The SQL Management Studio version used is v18.11.
3.Project Details: The project was developed using .NET Core 3.1 and Visual Studio 2019.
4.Connection String Configuration: Update the connection string to match your system settings. Specifically, adjust the Data Source, Username, and Password as needed in appsetting.